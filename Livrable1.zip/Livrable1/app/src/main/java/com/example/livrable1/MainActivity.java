package com.example.livrable1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btnLog;
    EditText editNom, editPassword;
    TextView j;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLog = (Button) findViewById(R.id.btnLog);
        editNom = (EditText) findViewById(R.id.editNom);
        editPassword = (EditText) findViewById(R.id.editPassword);


        btnLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OnLogButton(v);
            }
        });
    }

    public void OnLogButton(View view){
        Intent intent = new Intent (getApplicationContext(),Logged_in.class);
        startActivityForResult(intent,0);
    }


}